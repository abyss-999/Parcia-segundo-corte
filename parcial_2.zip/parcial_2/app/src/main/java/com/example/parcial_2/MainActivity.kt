package com.example.parcial_2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var nombre: EditText? = null
    private var apellido: EditText? = null
    private var acceder: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nombre = findViewById(R.id.nombre)
        apellido = findViewById(R.id.apellido)
        acceder = findViewById<Button>(R.id.accederButton)

        acceder?.setOnClickListener(View.OnClickListener {

            val nombreText = nombre?.text.toString()
            val apellidoText = apellido?.text.toString()


            val intent = Intent(this@MainActivity, MainActivity2::class.java)


            intent.putExtra("nombre", nombreText)
            intent.putExtra("apellido", apellidoText)

            startActivity(intent)
        })
    }
}
