package com.example.parcial_2
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    private var nombreMostrado: TextView? = null
    private var apellidoMostrado: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        nombreMostrado = findViewById(R.id.nombre_mostrado)
        apellidoMostrado = findViewById(R.id.apellido_mostrado)

        val extras = intent.extras
        if (extras != null) {

            val nombre = extras.getString("nombre")
            val apellido = extras.getString("apellido")

            nombreMostrado?.text = nombre
            apellidoMostrado?.text = apellido
        }
    }
}
